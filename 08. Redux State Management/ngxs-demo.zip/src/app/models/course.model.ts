export interface Course {
  name: string;
  url: string;
}