import { VoteComponent } from './vote.component'; 

describe('VoteComponent', () => {
  it('', () => {
  });

  it('', () => {
  });
});