import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './register.form.component.html'
})
export class RegisterFormComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}