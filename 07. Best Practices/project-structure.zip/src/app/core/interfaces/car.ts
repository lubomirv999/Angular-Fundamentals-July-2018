export interface ICar {
  model : string;
  make : string;
  engine: string;
}