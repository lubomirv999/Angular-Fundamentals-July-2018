export class RecipeCreateModel {
  constructor(
    public name : string,
    public description : string,
    public imagePath : string
  ) { }
}