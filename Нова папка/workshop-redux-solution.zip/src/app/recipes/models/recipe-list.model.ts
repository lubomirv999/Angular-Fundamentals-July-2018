export class RecipeListModel {
  constructor(
    public id : string,
    public name : string,
    public description : string,
    public imagePath : string
  ) { }
}