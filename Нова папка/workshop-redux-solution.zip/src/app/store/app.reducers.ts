import { recipesReducer } from "./reducers/recipes.reducer";

export const appReducers = {
  recipes: recipesReducer
}