import { RecipesState } from "./state/recipes.state";

export interface AppState {
  recipes: RecipesState
}