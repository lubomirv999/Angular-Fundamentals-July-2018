export class RecipeCreate {
  constructor(
    public name : string,
    public imagePath : string,
    public description : string
  ) { }
}