export class RecipeList {
  constructor(
    public id : string,
    public name : string,
    public imagePath : string,
    public description : string
  ) { }
}